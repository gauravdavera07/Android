package com.gaurav.allpractical;

import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Practical17Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical17);
        RadioGroup group = findViewById(R.id.group);
        TextView picked = findViewById(R.id.picked);
        group.setOnCheckedChangeListener((g, checkedId) -> {
            if (checkedId == R.id.opt_red) {
                picked.setText("Picked: Red theme");
            } else if (checkedId == R.id.opt_green) {
                picked.setText("Picked: Green theme");
            } else if (checkedId == R.id.opt_blue) {
                picked.setText("Picked: Blue theme");
            }
        });
    }
}
