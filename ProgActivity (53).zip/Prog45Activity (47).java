package com.gaurav.allpractical;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Practical47Activity extends AppCompatActivity {

    private static final String FILE = "internal_demo.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical47);
        EditText content = findViewById(R.id.content);
        Button write = findViewById(R.id.write);
        Button read = findViewById(R.id.read);
        write.setOnClickListener(v -> {
            try (OutputStreamWriter w = new OutputStreamWriter(openFileOutput(FILE, MODE_PRIVATE))) {
                w.write(content.getText().toString());
                Toast.makeText(this, "Written", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        read.setOnClickListener(v -> {
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(openFileInput(FILE)))) {
                StringBuilder b = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) {
                    b.append(line).append('\n');
                }
                content.setText(b.toString().trim());
            } catch (Exception e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
