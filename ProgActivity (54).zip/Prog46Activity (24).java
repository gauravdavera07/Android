package com.gaurav.allpractical;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

public class Practical25Activity extends AppCompatActivity {

    private ProgressBar progress;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int step;
    private Runnable ticker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical25);
        progress = findViewById(R.id.progress);
        Button toggle = findViewById(R.id.toggle_indeterminate);
        toggle.setOnClickListener(v -> progress.setIndeterminate(!progress.isIndeterminate()));
        Button simulate = findViewById(R.id.simulate);
        simulate.setOnClickListener(v -> startSimulated());
    }

    private void startSimulated() {
        if (ticker != null) {
            handler.removeCallbacks(ticker);
        }
        progress.setIndeterminate(false);
        progress.setMax(100);
        progress.setProgress(0);
        step = 0;
        ticker = new Runnable() {
            @Override
            public void run() {
                step += 5;
                progress.setProgress(Math.min(step, 100));
                if (step < 100) {
                    handler.postDelayed(this, 120);
                }
            }
        };
        handler.post(ticker);
    }

    @Override
    protected void onDestroy() {
        if (ticker != null) {
            handler.removeCallbacks(ticker);
        }
        super.onDestroy();
    }
}
