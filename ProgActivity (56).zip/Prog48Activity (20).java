package com.gaurav.allpractical;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import androidx.appcompat.app.AppCompatActivity;

public class Practical21Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical21);
        AutoCompleteTextView auto = findViewById(R.id.auto);
        String[] cities = getResources().getStringArray(R.array.autocomplete_cities);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, cities);
        auto.setAdapter(adapter);
    }
}
