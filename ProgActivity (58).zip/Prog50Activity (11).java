package com.gaurav.allpractical;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Practical12Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical12);
        ImageButton btn = findViewById(R.id.img_btn);
        btn.setOnClickListener(v ->
                Toast.makeText(this, "ImageButton clicked", Toast.LENGTH_SHORT).show());
    }
}
