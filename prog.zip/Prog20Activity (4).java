package com.gaurav.allpractical;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Practical06WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical06_welcome);
        String user = getIntent().getStringExtra(Practical06Activity.EXTRA_USERNAME);
        TextView welcome = findViewById(R.id.welcome);
        welcome.setText("Welcome, " + (user == null ? "" : user));
    }
}
