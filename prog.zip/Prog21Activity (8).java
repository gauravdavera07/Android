package com.gaurav.allpractical;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

public class Practical09Activity extends AppCompatActivity implements CountryListFragment.Listener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical09);
        if (savedInstanceState == null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.list_container, new CountryListFragment());
            ft.replace(R.id.detail_container,
                    CountryDetailFragment.newInstance("Select a country", null));
            ft.commit();
        }
    }

    @Override
    public void onCountrySelected(String name, @Nullable String flagImageUrl) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.detail_container, CountryDetailFragment.newInstance(name, flagImageUrl))
                .commit();
    }
}
