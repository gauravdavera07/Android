package com.gaurav.allpractical;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Practical34Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical34);
        Button b = findViewById(R.id.abs_btn);
        b.setOnClickListener(v ->
                Toast.makeText(this, "AbsoluteLayout button", Toast.LENGTH_SHORT).show());
    }
}
