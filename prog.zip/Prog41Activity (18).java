package com.gaurav.allpractical;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Practical19Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical19);
        EditText name = findViewById(R.id.name);
        Button go = findViewById(R.id.go);
        TextView label = findViewById(R.id.label);
        go.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            Toast.makeText(this, "Hello " + n, Toast.LENGTH_SHORT).show();
            label.setText("Hello " + n);
        });
    }
}
