package com.gaurav.allpractical;

import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Practical20Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical20);
        RatingBar rating = findViewById(R.id.rating);
        TextView value = findViewById(R.id.value);
        value.setText("Rating: " + rating.getRating());
        rating.setOnRatingBarChangeListener((bar, v, fromUser) ->
                value.setText("Rating: " + v));
    }
}
